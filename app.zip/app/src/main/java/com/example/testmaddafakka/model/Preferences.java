package com.example.testmaddafakka.model;

import java.util.ArrayList;

public class Preferences {

    private ArrayList <Category> example = new ArrayList<Category>();
}
