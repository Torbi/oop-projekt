package com.example.testmaddafakka;

import org.junit.Test;

public class IMDbAdapterTest {



    @Test
    public void getMovie() {

        //IMDbApiAdapter adapterThread = new IMDbApiAdapter();




        //assertEquals(250, list.size());
    }
}
